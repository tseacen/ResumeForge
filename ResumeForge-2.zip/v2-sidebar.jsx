// Sidebar — brand, new chat, recents grouped by day, user
function Sidebar({ activeChat, onNewChat, onSelectChat, onOpenSettings }) {
  // Group recents by day
  const grouped = React.useMemo(() => {
    const map = {};
    RECENT_CHATS.forEach(c => {
      if (!map[c.day]) map[c.day] = [];
      map[c.day].push(c);
    });
    return map;
  }, []);

  return (
    <aside className="sidebar">
      <div className="sb-top">
        <div className="sb-mark">
          <IcoSparkleClaude size={16} sw={1.8} />
        </div>
        <div className="sb-brand">Resume<em>Forge</em></div>
      </div>

      <button className="sb-new" onClick={onNewChat}>
        <IcoEdit size={15} />
        <span>Nouvelle adaptation</span>
        <span className="kbd">⌘ N</span>
      </button>

      <div className="sb-recents">
        {Object.entries(grouped).map(([day, items]) => (
          <div key={day}>
            <div className="sb-day">{day}</div>
            {items.map(c => (
              <button
                key={c.id}
                className={`sb-chat ${c.id === activeChat ? "active" : ""}`}
                onClick={() => onSelectChat && onSelectChat(c.id)}
              >
                <div className="sb-chat-title">{c.title}</div>
                <div className="sb-chat-meta">
                  <span className="score mono">{c.score}/100</span>
                  <span>·</span>
                  <span>Adapté</span>
                </div>
              </button>
            ))}
          </div>
        ))}
      </div>

      <div className="sb-foot">
        <div className="sb-user">
          <div className="sb-avatar">A</div>
          <div style={{ minWidth: 0 }}>
            <div className="sb-user-name">Alex Morgan</div>
            <div className="sb-user-plan">Plan Pro</div>
          </div>
        </div>
        <button className="sb-ico-btn" title="Réglages" onClick={onOpenSettings}>
          <IcoSettings size={16} />
        </button>
      </div>
    </aside>
  );
}

window.Sidebar = Sidebar;
