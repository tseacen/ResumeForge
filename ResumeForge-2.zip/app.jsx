// App shell — sidebar nav drives tab switching
function NavItem({ icon, label, count, active, disabled, onClick }) {
  return (
    <button
      className={`nav-item ${active ? "active" : ""} ${disabled ? "disabled" : ""}`}
      onClick={disabled ? undefined : onClick}
    >
      <span className="ni-icon">{icon}</span>
      {label}
      {count != null && <span className="ni-count mono">{count}</span>}
    </button>
  );
}

function App() {
  const [tab, setTab] = React.useState("analyze");
  const [resumeHtml, setResumeHtml] = React.useState(SAMPLE_RESUME_HTML);
  const [jobText, setJobText] = React.useState(SAMPLE_JOB);
  const [loading, setLoading] = React.useState(false);
  const [analyzed, setAnalyzed] = React.useState(true); // start "already analyzed" so the prototype shows everything
  const analysis = ANALYSIS;

  const onAnalyze = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setAnalyzed(true);
      setTab("report");
    }, 2200);
  };

  const tabs = [
    { id: "analyze",  label: "Analyze",  icon: <IconWand size={17} />, always: true },
    { id: "report",   label: "Report",   icon: <IconReport size={17} />, count: analysis.blockers.length + analysis.risks.length, gated: true },
    { id: "cv",       label: "CV",       icon: <IconDoc size={17} />, gated: true },
    { id: "audit",    label: "Audit",    icon: <IconList size={17} />, count: analysis.audit.length, gated: true },
    { id: "keywords", label: "Keywords", icon: <IconTag size={17} />, count: analysis.missing_keywords.filter(k => k.importance !== "bonus").length, gated: true },
  ];

  const current = tabs.find(t => t.id === tab) || tabs[0];

  const crumbsLabel = {
    analyze: "Analyze",
    report: "Fit report",
    cv: "CV preview",
    audit: "Audit trail",
    keywords: "Missing keywords",
  }[tab];

  return (
    <div className="app">
      {/* SIDEBAR */}
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">CT</div>
          <div>
            <div className="brand-name">CV Tailor</div>
            <div className="brand-sub mono">v0.4 · agent</div>
          </div>
        </div>

        <div className="nav-section">
          <div className="nav-eyebrow">Workspace</div>
          {tabs.slice(0, 1).map(t => (
            <NavItem key={t.id} icon={t.icon} label={t.label} active={tab === t.id} onClick={() => setTab(t.id)} />
          ))}
        </div>

        <div className="nav-section" style={{ paddingTop: 4 }}>
          <div className="nav-eyebrow">Results</div>
          {tabs.slice(1).map(t => (
            <NavItem
              key={t.id}
              icon={t.icon}
              label={t.label}
              count={t.count}
              active={tab === t.id}
              disabled={t.gated && !analyzed}
              onClick={() => setTab(t.id)}
            />
          ))}
        </div>

        <div className="sidebar-foot">
          <div className="nav-item" style={{ marginBottom: 4 }}>
            <span className="ni-icon"><IconCog size={17} /></span>
            Settings
          </div>
          <div className="user-card">
            <div className="avatar">AM</div>
            <div style={{ minWidth: 0 }}>
              <div className="user-name">Alex Morgan</div>
              <div className="user-mail">alex@hey.com</div>
            </div>
          </div>
        </div>
      </aside>

      {/* MAIN */}
      <div className="main">
        <div className="topbar">
          <div className="crumbs">
            <span>CV Tailor</span>
            <span className="sep">/</span>
            <span className="here">{crumbsLabel}</span>
          </div>
          <div className="top-actions">
            {analyzed && (
              <span className="status-chip">
                <span className="status-dot"></span>
                Last run · just now
              </span>
            )}
            <button className="pill-btn">
              <IconRefresh size={13} /> Re-run
            </button>
            <button className="pill-btn primary" onClick={() => setTab("analyze")}>
              <IconPlus size={13} sw={2.2} /> New tailoring
            </button>
          </div>
        </div>

        <div className="content">
          {tab === "analyze" && (
            <AnalyzeView
              resumeHtml={resumeHtml} setResumeHtml={setResumeHtml}
              jobText={jobText} setJobText={setJobText}
              onAnalyze={onAnalyze} loading={loading} analyzed={analyzed}
            />
          )}
          {tab === "report"   && analyzed && <ReportView   analysis={analysis} />}
          {tab === "cv"       && analyzed && <CvView       resumeHtml={resumeHtml} />}
          {tab === "audit"    && analyzed && <AuditView    analysis={analysis} />}
          {tab === "keywords" && analyzed && <KeywordsView analysis={analysis} />}

          {tab !== "analyze" && !analyzed && (
            <div className="empty-state">
              <div className="es-ico"><IconWand size={22} /></div>
              <div className="es-title">No analysis yet</div>
              <div className="es-text">Drop a resume and a job description on the Analyze tab to populate this view.</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
