// Data for v2 — recents, AI providers, mock chat flow
const RECENT_CHATS = [
  { id: "c1", title: "Staff Product Engineer — Lumen (Healthtech)", day: "Aujourd'hui", score: 92, active: true },
  { id: "c2", title: "Senior Frontend Engineer — Linear", day: "Aujourd'hui", score: 84 },
  { id: "c3", title: "Tech Lead — Notion (Berlin)", day: "Hier", score: 78 },
  { id: "c4", title: "Principal Engineer — Stripe Climate", day: "Hier", score: 88 },
  { id: "c5", title: "Staff Engineer — Vercel Edge", day: "Cette semaine", score: 81 },
  { id: "c6", title: "Engineering Manager — Figma", day: "Cette semaine", score: 73 },
  { id: "c7", title: "Founding Engineer — Anysphere", day: "Cette semaine", score: 90 },
  { id: "c8", title: "Senior SWE — Mistral AI (Paris)", day: "Le mois dernier", score: 86 },
];

const AI_PROVIDERS = [
  {
    id: "claude",
    name: "Claude Code",
    sub: "claude-sonnet-4.5 · CLI",
    desc: "L'assistant d'Anthropic. Précis, lent, raisonne sur le contexte avant d'écrire. Recommandé pour les CV.",
    install: "npm install -g @anthropic/claude-code",
  },
  {
    id: "codex",
    name: "OpenAI Codex",
    sub: "gpt-5-codex · CLI",
    desc: "Le CLI d'OpenAI. Rapide, créatif sur le phrasing. Bon pour itérer plusieurs variantes.",
    install: "npm install -g @openai/codex",
  },
];

// Mock chat flow — used to demo the "mid-flow" and "complete" states
const CHAT_FLOW = [
  {
    kind: "step",
    label: "Étape 1 · Coller l'offre",
    done: false,
  },
  {
    kind: "assistant",
    body: [
      "Bonjour Alex. Pour commencer, **collez la description complète du poste** ci-dessous — titre, missions, requis, préféré. Je vais comparer avec votre CV de base.",
      "Plus l'offre est complète, plus l'analyse sera précise.",
    ],
  },
  {
    kind: "action-paste",
    title: "Description du poste",
    placeholder: "Collez ici l'offre d'emploi complète…",
  },
];

const CHAT_MID = [
  { kind: "step", label: "Étape 1 · Offre reçue", done: true },
  {
    kind: "assistant",
    body: ["Bonjour Alex. Collez l'offre pour commencer."],
  },
  {
    kind: "user",
    body: "Staff Product Engineer — Healthtech (Remote / EU)\n\nWe are building the operating system for outpatient clinics across Europe…",
    truncated: true,
  },
  {
    kind: "assistant-typing",
    label: "J'analyse l'offre et la compare à votre CV…",
  },
  {
    kind: "assistant",
    body: [
      "J'ai parcouru l'offre. Voici le **diagnostic de compatibilité initial** avant adaptation :",
    ],
  },
  {
    kind: "stats",
    title: "Diagnostic initial",
    score: 78,
    delta: null,
    rows: [
      { label: "Compétences clés",    value: 84, tone: "good", icon: "target" },
      { label: "Pertinence expérience", value: 76, tone: "good", icon: "briefcase" },
      { label: "Mots-clés ATS",        value: 61, tone: "warn", icon: "tag" },
      { label: "Format & structure",   value: 92, tone: "good", icon: "layers" },
      { label: "Métriques d'impact",   value: 74, tone: "warn", icon: "chart" },
    ],
    needs: [
      { term: "FHIR R4", level: "miss" },
      { term: "WCAG 2.2", level: "miss" },
      { term: "GDPR", level: "miss" },
      { term: "HL7", level: "warn" },
      { term: "OpenEHR", level: "warn" },
    ],
  },
  { kind: "step", label: "Étape 2 · Questions complémentaires", done: false },
  {
    kind: "assistant",
    body: [
      "Avant d'adapter, il me manque quelques précisions. Votre CV ne mentionne pas certains éléments **demandés ou préférés** par le poste — je ne veux rien inventer.",
    ],
  },
  {
    kind: "question",
    label: "Question 1 sur 3",
    q: "Avez-vous une expérience pratique avec FHIR R4 ou HL7 ?",
    context: "Le poste cite l'interopérabilité FHIR comme préféré. Votre travail à Lumen Health touche aux dossiers patients — peut-on en parler ?",
    suggest: ["Oui, j'ai utilisé FHIR R4", "Non, jamais touché", "Vu en review uniquement"],
  },
];

const CHAT_DONE = [
  ...CHAT_MID,
  {
    kind: "user",
    body: "Oui, j'ai conçu les workflows de records patients à Lumen avec des reviews FHIR R4 — pas de prod hands-on direct, mais design + revue d'API.",
  },
  {
    kind: "assistant",
    body: [
      "Parfait. Je vais formuler ça comme **\"familier avec FHIR R4 via design & review\"** — honnête et utilisable. Question suivante :",
    ],
  },
  {
    kind: "question",
    label: "Question 2 sur 3",
    q: "L'offre cite WCAG 2.2 AA comme un driver. Avez-vous mené des audits a11y ?",
    context: "Vous mentionnez accessibilité en note, mais aucun bullet ne le surface.",
    suggest: ["Oui, audit Q1 sur le portail", "Connaissances générales", "Pas vraiment"],
  },
  {
    kind: "user",
    body: "Oui — j'ai mené un audit WCAG 2.2 sur le portail praticien au Q1 et corrigé les écarts AA.",
  },
  {
    kind: "assistant",
    body: ["Excellent, c'est un signal fort. Dernière question :"],
  },
  {
    kind: "question",
    label: "Question 3 sur 3",
    q: "Conformité GDPR / HDS — quel niveau d'exposition ?",
    context: "Healthtech EU implique presque toujours du GDPR ; HDS est spécifique France.",
    suggest: ["GDPR oui, HDS non", "Les deux", "Aucun"],
  },
  {
    kind: "user",
    body: "GDPR oui (analytics consentie à Lumen). HDS pas encore, mais je connais le cadre.",
  },
  { kind: "step", label: "Étape 3 · Génération du CV adapté", done: true },
  {
    kind: "generating-done",
    label: "Génération terminée — 3 sections réécrites, 1 ajoutée.",
  },
  {
    kind: "assistant",
    body: [
      "Votre CV adapté est prêt dans le panneau de droite. Voici les **statistiques finales** :",
    ],
  },
  {
    kind: "stats",
    title: "Compatibilité finale",
    score: 92,
    delta: "+14",
    rows: [
      { label: "Compétences clés",    value: 94, tone: "good", icon: "target" },
      { label: "Pertinence expérience", value: 90, tone: "good", icon: "briefcase" },
      { label: "Mots-clés ATS",        value: 88, tone: "good", icon: "tag" },
      { label: "Format & structure",   value: 95, tone: "good", icon: "layers" },
      { label: "Métriques d'impact",   value: 89, tone: "good", icon: "chart" },
    ],
    needs: [],
  },
  {
    kind: "assistant",
    body: [
      "**Trois éléments à valider** côté humain :",
      "• La ligne FHIR R4 est formulée comme « familier via design & review » — relisez pour confirmer le ton.",
      "• Le « 34% drop-off » est conservé tel quel — soyez prêt à expliquer la méthodologie en entretien.",
      "• HDS n'a **pas** été ajouté (vous n'avez pas l'exposition directe).",
    ],
  },
];

window.RECENT_CHATS = RECENT_CHATS;
window.AI_PROVIDERS = AI_PROVIDERS;
window.CHAT_FLOW = CHAT_FLOW;
window.CHAT_MID = CHAT_MID;
window.CHAT_DONE = CHAT_DONE;

// Sample CV HTML for the import-step textarea (was defined in legacy data.jsx)
const SAMPLE_RESUME_HTML = `<!DOCTYPE html>
<html>
<head><title>CV — Alex Morgan</title></head>
<body>
  <header>
    <h1>Alex Morgan</h1>
    <p>Senior Product Engineer · Berlin, DE</p>
    <p>alex.morgan@hey.com · github.com/amorgan</p>
  </header>

  <section>
    <h2>Expérience</h2>
    <article>
      <h3>Lead Engineer, Lumen Health</h3>
      <p>2022 — aujourd'hui</p>
      <ul>
        <li>Shipped patient-onboarding redesign that reduced drop-off by 34%.</li>
        <li>Owned migration from monolith to event-driven services on AWS.</li>
        <li>Hired and ran a 6-person platform squad across 3 timezones.</li>
      </ul>
    </article>
    <article>
      <h3>Senior Engineer, Frame.io</h3>
      <p>2019 — 2022</p>
      <ul>
        <li>Rebuilt asset-review pipeline; sustained 2× throughput at 1/3 cost.</li>
        <li>Open-sourced internal CRDT library, now 4.2k stars.</li>
      </ul>
    </article>
  </section>

  <section>
    <h2>Compétences</h2>
    <p>TypeScript · React · Node · Postgres · AWS · Kafka · Terraform</p>
  </section>
</body>
</html>`;
window.SAMPLE_RESUME_HTML = SAMPLE_RESUME_HTML;

// Resume model — used by preview
const V2_RESUME = {
  name: "Alex Morgan",
  title: "Senior Product Engineer · Berlin, DE",
  contact: "alex.morgan@hey.com · github.com/amorgan · +49 152 0000 0000",
  sections: [
    {
      title: "Résumé",
      kind: "summary",
      original: "Product-minded engineer with eight years building consumer and B2B web products. Cares about craft, ships steadily, leads small teams.",
      adapted:  "Staff-level product engineer (8 years) building regulated-domain web products end-to-end. Track record of measurable user-impact wins; mentors 4–6 senior engineers and owns subsystem-scale platform decisions.",
    },
    {
      title: "Expérience",
      kind: "experience",
      jobs: [
        {
          role: "Lead Engineer",
          company: "Lumen Health",
          period: "2022 — aujourd'hui",
          bullets: [
            { status: "proven",     text: "Shipped patient-onboarding redesign that reduced drop-off by 34%." },
            { status: "rewritten",
              original: "Led a rewrite of our platform from a monolith to microservices on AWS.",
              text:     "Owned migration from monolith to event-driven services on AWS — patient-records subsystem end-to-end." },
            { status: "rewritten",
              original: "Managed a team of engineers shipping features.",
              text:     "Hired and ran a 6-person platform squad across 3 timezones; set quarterly OKRs." },
            { status: "added",
              text:     "Familier avec FHIR R4 via design & review d'API (workflows records patients)." },
            { status: "added",
              text:     "Mené un audit WCAG 2.2 AA sur le portail praticien (Q1)." },
          ],
        },
        {
          role: "Senior Engineer",
          company: "Frame.io",
          period: "2019 — 2022",
          bullets: [
            { status: "proven", text: "Rebuilt asset-review pipeline; sustained 2× throughput at 1/3 cost." },
            { status: "proven", text: "Open-sourced internal CRDT library, now 4.2k stars." },
          ],
        },
      ],
    },
    {
      title: "Compétences",
      kind: "skills",
      original: "TypeScript · React · Node · Postgres · AWS · Kafka · Terraform",
      adapted:  "TypeScript · React (Next.js App Router) · Node · Postgres (read replicas, logical replication) · AWS · Kafka · Terraform · FHIR R4 · GDPR · WCAG 2.2",
    },
  ],
};

window.V2_RESUME = V2_RESUME;
