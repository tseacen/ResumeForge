// Mock analysis data — realistic shape mirroring the original Zod schemas
const SAMPLE_RESUME_HTML = `<!DOCTYPE html>
<html>
<head><title>Resume — Alex Morgan</title></head>
<body>
  <header>
    <h1>Alex Morgan</h1>
    <p>Senior Product Engineer · Berlin, DE</p>
    <p>alex.morgan@hey.com · github.com/amorgan</p>
  </header>

  <section>
    <h2>Experience</h2>
    <article>
      <h3>Lead Engineer, Lumen Health</h3>
      <p>2022 — Present</p>
      <ul>
        <li>Shipped patient-onboarding redesign that reduced drop-off by 34%.</li>
        <li>Owned migration from monolith to event-driven services on AWS.</li>
        <li>Hired and ran a 6-person platform squad across 3 timezones.</li>
      </ul>
    </article>
    <article>
      <h3>Senior Engineer, Frame.io</h3>
      <p>2019 — 2022</p>
      <ul>
        <li>Rebuilt asset-review pipeline; sustained 2× throughput at 1/3 cost.</li>
        <li>Open-sourced internal CRDT library, now 4.2k stars.</li>
      </ul>
    </article>
  </section>

  <section>
    <h2>Skills</h2>
    <p>TypeScript · React · Node · Postgres · AWS · Kafka · Terraform</p>
  </section>
</body>
</html>`;

const SAMPLE_JOB = `Staff Product Engineer — Healthtech (Remote / EU)

We are building the operating system for outpatient clinics across Europe.
Reporting to the VP Engineering, you will:

• Own the patient-records subsystem end-to-end (Postgres, event sourcing).
• Drive accessibility (WCAG 2.2 AA) across the practitioner web app.
• Partner with clinical informaticists on FHIR-based interoperability.
• Mentor 4–6 senior engineers; set quarterly platform OKRs.

Required:
- 8+ years building production web products with TypeScript.
- Deep React + Node experience, ideally with Next.js App Router.
- Postgres at scale (read replicas, partitioning, logical replication).
- Track record of measurable user-impact wins, not just shipping.

Preferred:
- HIPAA / GDPR / HDS exposure.
- FHIR R4, HL7, OpenEHR familiarity.
- Prior healthtech or regulated-domain experience.

Nice to have:
- Tauri / native desktop shells.
- Mistral / open-weights LLM integration experience.
- French language ability.`;

const ANALYSIS = {
  global_score: 78,
  risk_level: "moderate",
  sub_scores: [
    { id: "skills",     label: "Skills match",         icon: "target", value: 84 },
    { id: "experience", label: "Experience relevance", icon: "briefcase", value: 76 },
    { id: "keywords",   label: "Keyword coverage",     icon: "tag", value: 61 },
    { id: "format",     label: "Format & structure",   icon: "layers", value: 92 },
    { id: "impact",     label: "Impact metrics",       icon: "chart", value: 74 },
  ],
  strengths: [
    { title: "Quantified user-impact wins",
      text: "Onboarding redesign cites a concrete 34% drop-off reduction — directly maps to the JD's 'measurable user-impact wins, not just shipping' bullet." },
    { title: "Postgres + event-driven depth",
      text: "Lumen Health rewrite from monolith to event-driven services is a tight match for the records-subsystem ownership ask." },
    { title: "Track record of mentoring senior ICs",
      text: "Hired and ran a 6-person platform squad across timezones; satisfies the 4–6 senior engineer mentorship requirement." },
    { title: "TypeScript + React core stack",
      text: "Eight years TypeScript on the resume aligns with the JD's 8+ year requirement and primary language." },
  ],
  weaknesses: [
    { title: "No FHIR / HL7 mention",
      text: "Healthtech interoperability is a preferred qualification and the resume does not reference FHIR R4, HL7, or OpenEHR despite the candidate having relevant healthtech experience." },
    { title: "GDPR / HDS compliance language absent",
      text: "Compliance exposure is implied by Lumen Health but never named. Recruiters scanning for HIPAA/GDPR/HDS will miss this." },
    { title: "Accessibility work not surfaced",
      text: "WCAG 2.2 AA appears in the JD as a core driver; no a11y artifacts or claims on the resume." },
  ],
  blockers: [
    { num: "01", title: "Missing the keyword 'FHIR' anywhere on the resume",
      tag: "RECRUITER FILTER", tone: "red",
      body: "Most ATS screens for healthtech roles filter on FHIR exposure. Without the keyword, the resume risks being auto-rejected before a human reviewer sees it.",
      fix: "Add 'FHIR R4' to the Lumen Health bullet describing the records work, and to the Skills line." },
  ],
  risks: [
    { num: "02", title: "Cannot substantiate the 34% onboarding lift",
      tag: "SUBSTANTIATION", tone: "orange",
      body: "The number is strong but lacks methodology context — interviewers will ask 'how did you measure that' within the first 10 minutes. Have the cohort definition and instrumentation ready.",
      fix: "Prepare a 30-second answer: cohort, baseline, measurement window, and confounders ruled out." },
    { num: "03", title: "Gap between 'open-sourced CRDT library' and JD asks",
      tag: "RELEVANCE DRIFT", tone: "orange",
      body: "OSS work is a nice signal but doesn't map to the records-subsystem or clinical interoperability scope. Be ready to bridge it explicitly.",
      fix: "Frame the CRDT work as offline-capable collaborative editing, then connect to clinician workflows where connectivity is unreliable." },
  ],
  audit: [
    { section: "Header",
      classification: "proven",
      risk: "none",
      reason: "Identity and location verified against LinkedIn profile and prior portfolio site." },
    { section: "Lumen Health — bullet 1",
      classification: "needs_validation",
      risk: "moderate",
      reason: "34% drop-off reduction is plausible from cohort sizing but requires the candidate to confirm baseline and measurement window before public claim." },
    { section: "Lumen Health — bullet 2",
      classification: "rewritten",
      risk: "low",
      reason: "Original line read 'led a rewrite'. Rewritten to 'Owned migration from monolith to event-driven services on AWS' to mirror JD ownership phrasing." },
    { section: "Lumen Health — bullet 3",
      classification: "rewritten",
      risk: "low",
      reason: "Reframed team-leadership claim to emphasise 'hiring' and 'timezones' which the JD signals as scope indicators." },
    { section: "Frame.io — bullet 1",
      classification: "proven",
      risk: "none",
      reason: "Pipeline rebuild numbers cross-referenced with public talk at React Summit 2021." },
    { section: "Frame.io — bullet 2",
      classification: "proven",
      risk: "none",
      reason: "Star count and repo verified via GitHub API at run time." },
    { section: "Skills line",
      classification: "blocked",
      risk: "high",
      reason: "Cannot add 'FHIR' to skills without candidate confirmation — would constitute fabricated qualification under JD's regulated-domain framing." },
  ],
  missing_keywords: [
    { term: "FHIR R4",          importance: "required",  category: "Interop" },
    { term: "HL7",              importance: "required",  category: "Interop" },
    { term: "WCAG 2.2",         importance: "required",  category: "Accessibility" },
    { term: "GDPR",             importance: "required",  category: "Compliance" },
    { term: "HDS",              importance: "preferred", category: "Compliance" },
    { term: "OpenEHR",          importance: "preferred", category: "Interop" },
    { term: "Next.js App Router", importance: "preferred", category: "Stack" },
    { term: "logical replication", importance: "preferred", category: "Database" },
    { term: "partitioning",     importance: "preferred", category: "Database" },
    { term: "HIPAA",            importance: "preferred", category: "Compliance" },
    { term: "OKRs",             importance: "preferred", category: "Leadership" },
    { term: "Tauri",            importance: "bonus",     category: "Platform" },
    { term: "Mistral",          importance: "bonus",     category: "AI" },
    { term: "French",           importance: "bonus",     category: "Language" },
    { term: "outpatient",       importance: "bonus",     category: "Domain" },
    { term: "clinical informaticist", importance: "bonus", category: "Domain" },
  ],
};

window.SAMPLE_RESUME_HTML = SAMPLE_RESUME_HTML;
window.SAMPLE_JOB = SAMPLE_JOB;
window.ANALYSIS = ANALYSIS;

// Structured resume model — same source rendered as "original" or "adapted"
const RESUME_MODEL = {
  name: "Alex Morgan",
  title: "Senior Product Engineer · Berlin, DE",
  contact: ["alex.morgan@hey.com", "github.com/amorgan", "+49 152 0000 0000"],
  summary: {
    original: "Product-minded engineer with eight years building consumer and B2B web products. Cares about craft, ships steadily, leads small teams.",
    adapted:  "Staff-level product engineer (8 years) building regulated-domain web products end-to-end. Track record of measurable user-impact wins; mentors 4–6 senior engineers and owns subsystem-scale platform decisions.",
    status: "rewritten",
    rationale: "Mirrored the JD's phrasing — 'measurable user-impact wins', '4–6 senior engineers', 'subsystem ownership' — without inventing experience.",
  },
  experience: [
    {
      role: "Lead Engineer",
      company: "Lumen Health",
      period: "2022 — Present",
      bullets: [
        { status: "proven",
          text: "Shipped patient-onboarding redesign that reduced drop-off by 34%." },
        { status: "rewritten",
          original: "Led a rewrite of our platform from a monolith to microservices on AWS.",
          text:     "Owned migration from monolith to event-driven services on AWS — patient-records subsystem end-to-end.",
          rationale: "Reframed to mirror the JD's 'own the patient-records subsystem end-to-end' bullet. Scope is unchanged; phrasing is now JD-aligned." },
        { status: "rewritten",
          original: "Managed a team of engineers shipping features.",
          text:     "Hired and ran a 6-person platform squad across 3 timezones; set quarterly OKRs.",
          rationale: "JD signals 'mentor 4–6 senior engineers' and 'set quarterly platform OKRs'. Added 'OKRs' (substantiated by interview notes); kept headcount and timezones from the original." },
        { status: "added",
          text:     "Partnered with clinical informaticists on records workflows; familiar with FHIR R4 concepts from interop design reviews.",
          rationale: "BLOCKED — cannot claim FHIR R4 hands-on without candidate confirmation. Shown here greyed so you can approve, edit, or reject.",
          blocked: true },
      ],
    },
    {
      role: "Senior Engineer",
      company: "Frame.io",
      period: "2019 — 2022",
      bullets: [
        { status: "proven",
          text: "Rebuilt asset-review pipeline; sustained 2× throughput at 1/3 cost." },
        { status: "proven",
          text: "Open-sourced internal CRDT library, now 4.2k stars." },
      ],
    },
  ],
  skills: {
    original: "TypeScript · React · Node · Postgres · AWS · Kafka · Terraform",
    adapted:  "TypeScript · React (Next.js App Router) · Node · Postgres (read replicas, logical replication) · AWS · Kafka · Terraform",
    status: "rewritten",
    rationale: "Surfaced Next.js App Router and Postgres specifics already used at Lumen — both are JD-preferred and substantiated.",
  },
  notes: [
    "GDPR-aware: built consented-analytics layer at Lumen Health.",
    "WCAG 2.2 AA: shipped a11y audits for the practitioner portal in Q1.",
  ],
};

window.RESUME_MODEL = RESUME_MODEL;
