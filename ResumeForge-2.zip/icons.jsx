// Inline SVG icons — stroke style, 1.6-1.8 weight
const Icon = ({ d, size = 16, sw = 1.8, fill = "none", style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
    strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {typeof d === "string" ? <path d={d} /> : d}
  </svg>
);

const IconDoc = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
    <path d="M14 3v5h5" />
    <path d="M9 13h6M9 17h6M9 9h2" />
  </>
} />;

const IconBriefcase = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <rect x="3" y="7" width="18" height="13" rx="2" />
    <path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    <path d="M3 13h18" />
  </>
} />;

const IconChart = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M3 3v18h18" />
    <path d="M7 14l3-3 4 4 5-6" />
  </>
} />;

const IconReport = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M9 2h6l5 5v13a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h2z" />
    <path d="M9 13l2 2 4-4" />
  </>
} />;

const IconList = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M8 6h13M8 12h13M8 18h13" />
    <circle cx="4" cy="6" r="1" />
    <circle cx="4" cy="12" r="1" />
    <circle cx="4" cy="18" r="1" />
  </>
} />;

const IconTag = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M20.59 13.41 13.42 20.58a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" />
    <circle cx="7" cy="7" r="1.5" />
  </>
} />;

const IconUpload = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <path d="M17 8l-5-5-5 5" />
    <path d="M12 3v12" />
  </>
} />;

const IconCheck = (p) => <Icon size={p.size} sw={p.sw} d="M5 12l4 4L19 7" />;

const IconChevron = (p) => <Icon size={p.size} sw={p.sw} d="M9 6l6 6-6 6" />;

const IconWand = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M15 4V2M15 10V8M11 6h2M17 6h2" />
    <path d="m3 21 9-9" />
    <path d="m12.5 6.5 5 5" />
  </>
} />;

const IconBolt = (p) => <Icon size={p.size} sw={p.sw} d="M13 2 3 14h7v8l10-12h-7z" />;

const IconAlert = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
    <path d="M12 9v4M12 17h.01" />
  </>
} />;

const IconShield = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    <path d="m9 12 2 2 4-4" />
  </>
} />;

const IconTarget = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="5" />
    <circle cx="12" cy="12" r="1.5" />
  </>
} />;

const IconLayers = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="m12 2 10 5-10 5L2 7l10-5z" />
    <path d="m2 17 10 5 10-5M2 12l10 5 10-5" />
  </>
} />;

const IconSparkle = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M12 3v3M12 18v3M3 12h3M18 12h3" />
    <path d="m5.5 5.5 2 2M16.5 16.5l2 2M18.5 5.5l-2 2M7.5 16.5l-2 2" />
  </>
} />;

const IconDownload = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <path d="M7 10l5 5 5-5" />
    <path d="M12 15V3" />
  </>
} />;

const IconCopy = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <rect x="9" y="9" width="13" height="13" rx="2" />
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
  </>
} />;

const IconPrint = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M6 9V2h12v7" />
    <rect x="3" y="9" width="18" height="9" rx="2" />
    <rect x="6" y="14" width="12" height="8" rx="1" />
  </>
} />;

const IconCircleX = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <circle cx="12" cy="12" r="9" />
    <path d="M9 9l6 6M15 9l-6 6" />
  </>
} />;

const IconClose = (p) => <Icon size={p.size} sw={p.sw} d="M6 6l12 12M18 6l-12 12" />;

const IconRefresh = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M21 12a9 9 0 1 1-3-6.7" />
    <path d="M21 4v5h-5" />
  </>
} />;

const IconCog = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9 1.65 1.65 0 0 0 4.27 7.18l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.36.06.7.21 1 .4.34.21.62.5.81.83A1.65 1.65 0 0 0 21 11h.09a2 2 0 1 1 0 4H21a1.65 1.65 0 0 0-1.6 1z" />
  </>
} />;

const IconPlus = (p) => <Icon size={p.size} sw={p.sw} d="M12 5v14M5 12h14" />;

const IconFile = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <path d="M14 2v6h6" />
  </>
} />;

const IconCode = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="m16 18 6-6-6-6" />
    <path d="m8 6-6 6 6 6" />
  </>
} />;

const IconSearch = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <circle cx="11" cy="11" r="7" />
    <path d="m21 21-4.3-4.3" />
  </>
} />;

const IconCircleDot = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="2" fill="currentColor" stroke="none" />
  </>
} />;

const IconHourglass = (p) => <Icon size={p.size} sw={p.sw} d={
  <>
    <path d="M6 2h12M6 22h12" />
    <path d="M6 2c0 4 6 6 6 10s-6 6-6 10" />
    <path d="M18 2c0 4-6 6-6 10s6 6 6 10" />
  </>
} />;

const IconArrow = (p) => <Icon size={p.size} sw={p.sw} d="M5 12h14M13 5l7 7-7 7" />;

Object.assign(window, {
  IconDoc, IconBriefcase, IconChart, IconReport, IconList, IconTag,
  IconUpload, IconCheck, IconChevron, IconWand, IconBolt, IconAlert,
  IconShield, IconTarget, IconLayers, IconSparkle, IconDownload,
  IconCopy, IconPrint, IconCircleX, IconClose, IconRefresh, IconCog,
  IconPlus, IconFile, IconCode, IconSearch, IconCircleDot, IconHourglass, IconArrow
});
