// Extra icons for v2 — Claude-style flow
const V2Icon = ({ d, size = 16, sw = 1.7, fill = "none", style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
    strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {typeof d === "string" ? <path d={d} /> : d}
  </svg>
);

const IcoChat = (p) => <V2Icon {...p} d={<>
  <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
</>} />;

const IcoSettings = (p) => <V2Icon {...p} d={<>
  <circle cx="12" cy="12" r="3" />
  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9 1.65 1.65 0 0 0 4.27 7.18l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.06.07.21.21.4.5.34.21.62.5.81.83A1.65 1.65 0 0 0 21 11h.09a2 2 0 1 1 0 4H21a1.65 1.65 0 0 0-1.6 1z" />
</>} />;

const IcoSend = (p) => <V2Icon {...p} d={<>
  <path d="M5 12l14-7-4 14-3-6-7-1z" />
</>} />;

const IcoAttach = (p) => <V2Icon {...p} d={<>
  <path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
</>} />;

const IcoSparkleClaude = (p) => <V2Icon {...p} d={<>
  <path d="M12 3l1.5 5 5 1.5-5 1.5L12 16l-1.5-5L5.5 9.5l5-1.5z" />
  <path d="M19 14l.7 2.3 2.3.7-2.3.7-.7 2.3-.7-2.3-2.3-.7 2.3-.7z" />
</>} />;

const IcoLight = (p) => <V2Icon {...p} d={<>
  <path d="M9 18h6" />
  <path d="M10 22h4" />
  <path d="M12 2a7 7 0 0 0-4 12.74V17h8v-2.26A7 7 0 0 0 12 2z" />
</>} />;

const IcoMic = (p) => <V2Icon {...p} d={<>
  <rect x="9" y="2" width="6" height="13" rx="3" />
  <path d="M19 11a7 7 0 0 1-14 0" />
  <path d="M12 18v4M8 22h8" />
</>} />;

const IcoTerminal = (p) => <V2Icon {...p} d={<>
  <rect x="3" y="4" width="18" height="16" rx="2" />
  <path d="m7 9 3 3-3 3M13 15h4" />
</>} />;

const IcoAnthropic = (p) => (
  <svg width={p.size || 22} height={p.size || 22} viewBox="0 0 24 24" fill="currentColor">
    <path d="M6.4 5h3.05l5.55 14H11.9l-1.13-3H5.3l-1.13 3H1L6.4 5zm.83 8.45h2.79L8.62 9.5l-1.4 3.95zM17.65 5H21l-5.55 14h-2.95L17.65 5z" />
  </svg>
);

const IcoOpenAI = (p) => (
  <svg width={p.size || 22} height={p.size || 22} viewBox="0 0 24 24" fill="currentColor">
    <path d="M22.28 9.82a5.95 5.95 0 0 0-.51-4.91 6.04 6.04 0 0 0-6.5-2.9A6 6 0 0 0 4.98 4.18a5.98 5.98 0 0 0-4 2.9 6.04 6.04 0 0 0 .74 7.08 5.95 5.95 0 0 0 .51 4.91 6.04 6.04 0 0 0 6.5 2.9A6 6 0 0 0 19.02 19.82a5.98 5.98 0 0 0 4-2.9 6.04 6.04 0 0 0-.74-7.1zM13.4 21.27a4.48 4.48 0 0 1-2.85-1.03l.14-.08 4.76-2.75c.24-.14.39-.4.39-.68v-6.71l2.01 1.17.02.05v5.55a4.5 4.5 0 0 1-4.47 4.48zM3.77 17.16a4.46 4.46 0 0 1-.53-3.02l.14.09 4.77 2.75c.24.14.53.14.77 0l5.81-3.36v2.32l.01.06-4.81 2.78a4.5 4.5 0 0 1-6.16-1.62zM2.52 6.59a4.46 4.46 0 0 1 2.34-1.97v5.65c0 .28.15.54.39.68l5.81 3.36-2.01 1.16-.06-.02-4.81-2.78a4.5 4.5 0 0 1-1.66-6.08zm16.55 3.86-5.81-3.37 2-1.16.06.02 4.81 2.79a4.49 4.49 0 0 1-.68 8.1V11.13a.83.83 0 0 0-.38-.68zm2-3.01-.14-.09-4.76-2.78a.78.78 0 0 0-.78 0L9.58 7.94V5.62l.01-.06 4.8-2.77a4.49 4.49 0 0 1 6.67 4.66zM8.48 11.6 6.47 10.43l-.02-.06V4.84a4.5 4.5 0 0 1 7.37-3.45l-.14.08-4.76 2.76c-.24.14-.39.4-.39.68v6.7zm1.1-2.35L12.18 7.75l2.59 1.5v2.99l-2.58 1.5L9.58 12.25z"/>
  </svg>
);

const IcoCircle = (p) => <V2Icon {...p} sw={2} d={<>
  <circle cx="12" cy="12" r="9" />
</>} />;

const IcoCheckCircle = (p) => <V2Icon {...p} d={<>
  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
  <path d="m22 4-10 10.01-3-3" />
</>} />;

const IcoQuestion = (p) => <V2Icon {...p} d={<>
  <circle cx="12" cy="12" r="9" />
  <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
  <path d="M12 17h.01" />
</>} />;

const IcoArrowUp = (p) => <V2Icon {...p} sw={2} d="M12 19V5M5 12l7-7 7 7" />;

const IcoCommand = (p) => <V2Icon {...p} d={<>
  <path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3H6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z" />
</>} />;

const IcoFolder = (p) => <V2Icon {...p} d={<>
  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
</>} />;

const IcoStar = (p) => <V2Icon {...p} d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />;

const IcoHistory = (p) => <V2Icon {...p} d={<>
  <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
  <path d="M3 3v5h5" />
  <path d="M12 7v5l3 2" />
</>} />;

const IcoLogout = (p) => <V2Icon {...p} d={<>
  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
  <path d="m16 17 5-5-5-5" />
  <path d="M21 12H9" />
</>} />;

const IcoTrash = (p) => <V2Icon {...p} d={<>
  <path d="M3 6h18" />
  <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
</>} />;

const IcoEdit = (p) => <V2Icon {...p} d={<>
  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
  <path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z" />
</>} />;

const IcoTestTube = (p) => <V2Icon {...p} d={<>
  <path d="M14 2v6L20 14a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4l6-6V2" />
  <path d="M8 2h8" />
  <path d="M8 14h8" />
</>} />;

const IcoCheck2 = (p) => <V2Icon {...p} sw={2.2} d="M5 12l4 4L19 7" />;

const IcoEye = (p) => <V2Icon {...p} d={<>
  <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" />
  <circle cx="12" cy="12" r="3" />
</>} />;

const IcoExternal = (p) => <V2Icon {...p} d={<>
  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
  <path d="M15 3h6v6M10 14L21 3" />
</>} />;

// Aliases bridging to the legacy icons.jsx set (already on window)
const IcoDoc       = (p) => <IconDoc {...p} />;
const IcoRefresh   = (p) => <IconRefresh {...p} />;
const IcoUpload    = (p) => <IconUpload {...p} />;
const IcoDownload  = (p) => <IconDownload {...p} />;
const IcoChart     = (p) => <IconChart {...p} />;
const IcoTarget    = (p) => <IconTarget {...p} />;
const IcoBriefcase = (p) => <IconBriefcase {...p} />;
const IcoTag       = (p) => <IconTag {...p} />;
const IcoLayers    = (p) => <IconLayers {...p} />;

Object.assign(window, {
  IcoChat, IcoSettings, IcoSend, IcoAttach, IcoSparkleClaude, IcoLight, IcoMic,
  IcoTerminal, IcoAnthropic, IcoOpenAI, IcoCircle, IcoCheckCircle, IcoQuestion,
  IcoArrowUp, IcoCommand, IcoFolder, IcoStar, IcoHistory, IcoLogout,
  IcoTrash, IcoEdit, IcoTestTube, IcoCheck2, IcoEye, IcoExternal,
  IcoDoc, IcoRefresh, IcoUpload, IcoDownload, IcoChart,
  IcoTarget, IcoBriefcase, IcoTag, IcoLayers,
});
