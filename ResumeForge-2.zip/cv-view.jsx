// CV preview — renders structured model with adapted / original / diff modes
// Highlights every line the agent rewrote, added, or had to block.

function collectChanges(model) {
  const out = [];
  if (model.summary.status !== "proven") {
    out.push({ id: "summary", section: "Summary", ...model.summary });
  }
  model.experience.forEach((job, ji) => {
    job.bullets.forEach((b, bi) => {
      if (b.status !== "proven") {
        out.push({
          id: `exp-${ji}-${bi}`,
          section: `${job.company} — bullet ${bi + 1}`,
          ...b,
        });
      }
    });
  });
  if (model.skills.status !== "proven") {
    out.push({ id: "skills", section: "Skills", ...model.skills });
  }
  return out;
}

function ChangeMarker({ status, blocked, onClick, active }) {
  const tone =
    blocked ? "blocked" :
    status === "added" ? "added" :
    status === "rewritten" ? "rewritten" : null;
  if (!tone) return null;
  return (
    <button
      className={`change-marker ${tone} ${active ? "active" : ""}`}
      onClick={onClick}
      title={
        tone === "rewritten" ? "Rewritten — click for original" :
        tone === "added" ? "Added by the agent" :
        "Blocked — needs your approval"
      }
    >
      <span className="cm-dot"></span>
    </button>
  );
}

function CvLine({ id, status, blocked, mode, originalText, adaptedText, rationale, onSelect, selectedId }) {
  const active = selectedId === id;

  if (mode === "original") {
    if (status === "added") return null;
    return <li className="cv-bullet" data-line-id={id}>{originalText || adaptedText}</li>;
  }

  if (mode === "diff") {
    return (
      <li className={`cv-bullet diff ${status}`} data-line-id={id}>
        {status === "rewritten" && originalText && (
          <span className="diff-line removed">{originalText}</span>
        )}
        <span className={`diff-line ${status === "added" ? "added" : status === "rewritten" ? "added" : ""}`}>
          {adaptedText}
        </span>
      </li>
    );
  }

  // adapted (default)
  const isBlocked = !!blocked;
  return (
    <li
      className={`cv-bullet ${status} ${active ? "active" : ""} ${isBlocked ? "blocked" : ""}`}
      data-line-id={id}
      onClick={() => onSelect && onSelect(id)}
    >
      <ChangeMarker status={status} blocked={isBlocked} active={active} />
      <span className="cv-bullet-text">{adaptedText}</span>
    </li>
  );
}

function CvParagraph({ id, status, mode, original, adapted, onSelect, selectedId }) {
  const active = selectedId === id;
  if (mode === "original") return <p className="cv-para" data-line-id={id}>{original}</p>;

  if (mode === "diff") {
    return (
      <div className={`cv-para diff ${status}`} data-line-id={id}>
        {status === "rewritten" && (
          <p className="diff-line removed">{original}</p>
        )}
        <p className={`diff-line ${status === "rewritten" ? "added" : ""}`}>{adapted}</p>
      </div>
    );
  }

  return (
    <p
      className={`cv-para ${status} ${active ? "active" : ""}`}
      data-line-id={id}
      onClick={() => status !== "proven" && onSelect && onSelect(id)}
    >
      <ChangeMarker status={status} active={active} />
      <span className="cv-para-text">{adapted}</span>
    </p>
  );
}

function CvDocument({ model, mode, selectedId, onSelect }) {
  return (
    <div className="cv-paper">
      <header className="cv-header">
        <h1>{model.name}</h1>
        <p className="cv-title">{model.title}</p>
        <p className="cv-contact mono">{model.contact.join(" · ")}</p>
      </header>

      <section>
        <h2>Summary</h2>
        <CvParagraph
          id="summary"
          status={model.summary.status}
          mode={mode}
          original={model.summary.original}
          adapted={model.summary.adapted}
          onSelect={onSelect}
          selectedId={selectedId}
        />
      </section>

      <section>
        <h2>Experience</h2>
        {model.experience.map((job, ji) => (
          <article key={ji} className="cv-job">
            <h3>{job.role} · {job.company}</h3>
            <p className="cv-period mono">{job.period}</p>
            <ul className="cv-bullets">
              {job.bullets.map((b, bi) => (
                <CvLine
                  key={bi}
                  id={`exp-${ji}-${bi}`}
                  status={b.status}
                  blocked={b.blocked}
                  mode={mode}
                  originalText={b.original}
                  adaptedText={b.text}
                  rationale={b.rationale}
                  onSelect={onSelect}
                  selectedId={selectedId}
                />
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section>
        <h2>Skills</h2>
        <CvParagraph
          id="skills"
          status={model.skills.status}
          mode={mode}
          original={model.skills.original}
          adapted={model.skills.adapted}
          onSelect={onSelect}
          selectedId={selectedId}
        />
      </section>
    </div>
  );
}

function ChangeCard({ change, active, onClick, onAccept, onReject }) {
  const toneLabel = {
    rewritten: "Rewritten",
    added: "Added",
  };
  return (
    <div className={`change-card ${change.status} ${active ? "active" : ""} ${change.blocked ? "blocked" : ""}`} onClick={onClick}>
      <div className="change-card-head">
        <span className={`change-tag ${change.blocked ? "blocked" : change.status}`}>
          {change.blocked ? "Needs approval" : toneLabel[change.status] || change.status}
        </span>
        <span className="change-section">{change.section}</span>
      </div>
      {change.original && (
        <div className="change-original">
          <div className="cc-label">Was</div>
          <div className="cc-text">{change.original}</div>
        </div>
      )}
      <div className="change-adapted">
        <div className="cc-label">{change.original ? "Now" : "Inserted"}</div>
        <div className="cc-text">{change.adapted || change.text}</div>
      </div>
      {change.rationale && (
        <div className="change-rationale">{change.rationale}</div>
      )}
      {change.blocked && (
        <div className="change-actions" onClick={(e) => e.stopPropagation()}>
          <button className="pill-btn primary sm" onClick={onAccept}>Approve</button>
          <button className="pill-btn sm" onClick={onReject}>Reject</button>
        </div>
      )}
    </div>
  );
}

function CvView({ resumeHtml }) {
  const model = window.RESUME_MODEL;
  const [mode, setMode] = React.useState("adapted"); // adapted | original | diff
  const [selectedId, setSelectedId] = React.useState(null);
  const [accepted, setAccepted] = React.useState({}); // { id: true/false }

  const changes = React.useMemo(() => collectChanges(model), [model]);
  const pendingBlocked = changes.filter(c => c.blocked && accepted[c.id] !== false && accepted[c.id] !== true).length;
  const totalChanges = changes.length;

  React.useEffect(() => {
    if (!selectedId) return;
    const el = document.querySelector(`[data-line-id="${selectedId}"]`);
    if (el) el.scrollIntoView({ block: "center", behavior: "smooth" });
  }, [selectedId]);

  return (
    <div className="tab-fade">
      <div className="page-title-row">
        <div>
          <h1 className="h1">CV preview</h1>
          <div className="lede">Your resume, tailored to this job — every change tagged, sourced, and reversible. Nothing is fabricated.</div>
        </div>
      </div>

      <div className="cv-wrap">
        <div className="card cv-frame-card">
          <div className="cv-toolbar">
            <div className="cv-tabs">
              <button className={mode === "adapted" ? "on" : ""} onClick={() => setMode("adapted")}>
                Adapted <span className="tab-badge">{totalChanges}</span>
              </button>
              <button className={mode === "original" ? "on" : ""} onClick={() => setMode("original")}>
                Original
              </button>
              <button className={mode === "diff" ? "on" : ""} onClick={() => setMode("diff")}>
                Diff
              </button>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span className="status-chip">
                <span className="status-dot"></span>
                {`${totalChanges} change${totalChanges !== 1 ? "s" : ""} · ${pendingBlocked} pending`}
              </span>
              <button className="pill-btn sm">
                <IconDownload size={13} /> PDF
              </button>
            </div>
          </div>

          <div className="cv-frame-host">
            <div className="cv-iframe-paper">
              <CvDocument
                model={model}
                mode={mode}
                selectedId={selectedId}
                onSelect={setSelectedId}
              />
            </div>
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
          <div className="card cv-aside-card">
            <div className="aside-head">
              <div>
                <div className="card-eyebrow">Tailoring</div>
                <div className="card-title">{`${totalChanges} change${totalChanges !== 1 ? "s" : ""} applied`}</div>
              </div>
              <button className="pill-btn ghost sm" onClick={() => setMode(mode === "diff" ? "adapted" : "diff")}>
                {mode === "diff" ? "Hide diff" : "Show diff"}
              </button>
            </div>

            <div className="change-list">
              {changes.map((c) => (
                <ChangeCard
                  key={c.id}
                  change={c}
                  active={selectedId === c.id}
                  onClick={() => setSelectedId(c.id)}
                  onAccept={() => setAccepted({ ...accepted, [c.id]: true })}
                  onReject={() => setAccepted({ ...accepted, [c.id]: false })}
                />
              ))}
            </div>
          </div>

          <div className="card cv-aside-card">
            <div className="card-eyebrow">Export</div>
            <div className="card-title">Send this somewhere</div>
            <div className="cv-export-list">
              <button className="cv-export-btn">
                <span className="xico"><IconDownload size={14} /></span>
                <span>
                  <div>Download PDF (adapted)</div>
                  <div className="xsub">A4, embedded fonts</div>
                </span>
              </button>
              <button className="cv-export-btn">
                <span className="xico"><IconCode size={14} /></span>
                <span>
                  <div>Copy HTML source</div>
                  <div className="xsub">Stripped of editor markup</div>
                </span>
              </button>
              <button className="cv-export-btn">
                <span className="xico"><IconFile size={14} /></span>
                <span>
                  <div>Export as .docx</div>
                  <div className="xsub">Editable Word document</div>
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.CvView = CvView;
