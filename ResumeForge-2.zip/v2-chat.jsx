// Chat view — stream of messages with steps, stats, questions, action cards

function StepBadge({ label, done }) {
  return (
    <div className="msg-step">
      <span className={`step-num ${done ? "done" : ""}`}>
        {done ? <IcoCheck2 size={10} sw={2.4} /> : <span style={{ width: 4, height: 4, borderRadius: 999, background: "white" }}></span>}
      </span>
      {label}
    </div>
  );
}

function AssistantAvatar() {
  return <div className="av"><IcoSparkleClaude size={15} sw={1.8} /></div>;
}

function AssistantMessage({ children }) {
  return (
    <div className="msg-assistant">
      <AssistantAvatar />
      <div className="msg-body">{children}</div>
    </div>
  );
}

function ParagraphFromMarkdown({ text }) {
  // Render very simple markdown: **bold** + `code` highlights
  const parts = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`)/g;
  let last = 0; let m; let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const seg = m[0];
    if (seg.startsWith("**")) parts.push(<strong key={i++}>{seg.slice(2, -2)}</strong>);
    else parts.push(<em key={i++} className="term">{seg.slice(1, -1)}</em>);
    last = m.index + seg.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return <p>{parts}</p>;
}

function UserMessage({ body, truncated }) {
  const [expanded, setExpanded] = React.useState(false);
  const shown = truncated && !expanded
    ? body.slice(0, 180) + "…"
    : body;
  return (
    <div className="msg-user">
      <div className="bubble" style={{ whiteSpace: "pre-wrap" }}>
        {shown}
        {truncated && (
          <button
            onClick={() => setExpanded(e => !e)}
            style={{ display: "block", marginTop: 6, fontSize: 12, color: "var(--accent)", fontWeight: 500 }}
          >
            {expanded ? "Réduire" : "Tout afficher"}
          </button>
        )}
      </div>
    </div>
  );
}

function ActionPaste({ title, placeholder, onSubmit }) {
  const [val, setVal] = React.useState("");
  return (
    <div className="action-card">
      <div className="ac-head">
        <div className="ico"><IcoCommand size={15} /></div>
        <div className="ac-title">{title}</div>
      </div>
      <textarea
        className="ac-textarea"
        value={val}
        onChange={e => setVal(e.target.value)}
        placeholder={placeholder}
      />
      <div className="ac-foot">
        <div className="hint">Le texte est traité localement par votre IA configurée.</div>
        <div style={{ display: "flex", gap: 6 }}>
          <button className="btn sm"><IcoFolder size={12} /> Depuis fichier</button>
          <button className="btn primary sm" disabled={val.length < 50} onClick={() => onSubmit && onSubmit(val)}>
            <IcoArrowUp size={12} sw={2.4} /> Lancer l'analyse
          </button>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ title, score, delta, rows, needs }) {
  // Animate bars on mount
  const [animated, setAnimated] = React.useState(false);
  React.useEffect(() => {
    const t = setTimeout(() => setAnimated(true), 80);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="stats-card fade-in">
      <div className="stats-head">
        <div className="stats-title">
          <span className="ico"><IcoChart size={14} sw={2} /></span>
          {title}
        </div>
        <div className="stats-score">
          <span className="num">{score}</span>
          <span className="of mono">/100</span>
          {delta && <span className="delta">{delta} pts</span>}
        </div>
      </div>
      <div className="stats-rows">
        {rows.map((r, i) => (
          <div key={i} className="stats-row">
            <div className="lbl">
              <span className="lico">{r.icon === "target" ? <IcoTarget size={13} sw={1.8} /> : r.icon === "briefcase" ? <IcoBriefcase size={13} sw={1.8} /> : r.icon === "tag" ? <IcoTag size={13} sw={1.8} /> : r.icon === "layers" ? <IcoLayers size={13} sw={1.8} /> : <IcoChart size={13} sw={1.8} />}</span>
              {r.label}
            </div>
            <div className="stats-bar">
              <div className={`fill ${r.tone}`} style={{ width: animated ? `${r.value}%` : "0%" }}></div>
            </div>
            <div className="v">{r.value}</div>
          </div>
        ))}
      </div>
      {needs && needs.length > 0 && (
        <div className="stats-foot">
          <span className="key">Manquants détectés :</span>
          {needs.map((n, i) => (
            <span key={i} className={`needs-chip ${n.level}`}>
              <span className="dot"></span>{n.term}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function QuestionCard({ label, q, context, suggest, onAnswer }) {
  return (
    <div className="question-card">
      <div className="qc-head">
        <span className="ico"><IcoQuestion size={13} sw={2} /></span>
        {label}
      </div>
      <div className="qc-q">{q}</div>
      <div className="qc-context">{context}</div>
      {suggest && suggest.length > 0 && (
        <div className="qc-suggest">
          {suggest.map((s, i) => (
            <button key={i} className="s-pill" onClick={() => onAnswer && onAnswer(s)}>{s}</button>
          ))}
        </div>
      )}
    </div>
  );
}

function GeneratingCard({ label, done }) {
  return (
    <div className="gen-card">
      <div className="gen-ico">
        {done ? <IcoCheck2 size={14} sw={2.4} /> : <IcoSparkleClaude size={14} sw={1.8} />}
      </div>
      <div style={{ flex: 1 }}>
        <div className="gen-text">
          {done ? <strong>{label}</strong> : <>Génération en cours · <strong>{label || "réécriture des bullets"}</strong></>}
        </div>
        {!done && (
          <div className="gen-progress"><div className="gp-fill"></div></div>
        )}
      </div>
    </div>
  );
}

function TypingMessage({ label }) {
  return (
    <div className="msg-assistant">
      <AssistantAvatar />
      <div className="msg-body">
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div className="typing-dots"><span></span><span></span><span></span></div>
          <span style={{ color: "var(--muted)", fontSize: 13 }}>{label}</span>
        </div>
      </div>
    </div>
  );
}

function Composer({ disabled, placeholder }) {
  const [val, setVal] = React.useState("");
  const ref = React.useRef(null);
  React.useEffect(() => {
    const el = ref.current; if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 140) + "px";
  }, [val]);
  return (
    <div className="composer-wrap">
      <div className="composer">
        <textarea
          ref={ref}
          value={val}
          onChange={e => setVal(e.target.value)}
          placeholder={placeholder || "Répondre, ou demander une modification…"}
          rows={1}
          disabled={disabled}
        />
        <div className="composer-actions">
          <button className="comp-ico" title="Joindre un fichier"><IcoAttach size={15} /></button>
          <button className="comp-ico" title="Dicter"><IcoMic size={15} /></button>
          <button className="comp-send" disabled={!val.trim()}>
            <IcoArrowUp size={14} sw={2.4} />
          </button>
        </div>
      </div>
      <div className="comp-hint">
        <span>Claude Code · <span className="mono" style={{ color: "var(--success)" }}>● connecté</span></span>
        <span><span className="kbd">⏎</span> pour envoyer · <span className="kbd">⇧⏎</span> nouvelle ligne</span>
      </div>
    </div>
  );
}

function Welcome({ onStart }) {
  return (
    <div className="chat-scroll">
      <div className="welcome-wrap">
        <div className="welcome">
          <div className="welcome-eye"><span className="dot"></span> Prêt</div>
          <h1 className="welcome-h1">Quelle offre <em>adapter</em> aujourd'hui ?</h1>
          <p className="welcome-sub">
            Collez une description de poste pour commencer. Je vais comparer à votre CV,
            vous poser quelques questions, puis générer une version adaptée — sans rien inventer.
          </p>
          <div className="welcome-suggest">
            <button className="ws-card" onClick={onStart}>
              <div className="ws-t">📋 Coller une offre</div>
              <div className="ws-s">Description complète — titre, missions, requis.</div>
            </button>
            <button className="ws-card">
              <div className="ws-t">🔗 Depuis une URL</div>
              <div className="ws-s">LinkedIn, Welcome to the Jungle, Lever, Ashby.</div>
            </button>
            <button className="ws-card">
              <div className="ws-t">📂 Reprendre une session</div>
              <div className="ws-s">Voir vos 8 adaptations récentes.</div>
            </button>
            <button className="ws-card">
              <div className="ws-t">✏️ Modifier le CV de base</div>
              <div className="ws-s">Mettre à jour le CV maître avant adaptation.</div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ChatView({ phase, onPasteSubmit }) {
  // phase: "empty" | "diagnostic" | "questions" | "adapted"
  const stream = phase === "diagnostic" ? CHAT_MID : phase === "adapted" ? CHAT_DONE : null;

  const scrollRef = React.useRef(null);
  React.useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [phase]);

  if (phase === "empty") {
    return (
      <div className="chat-pane">
        <Welcome onStart={onPasteSubmit} />
        <Composer placeholder="Collez l'offre d'emploi, ou tapez une question…" />
      </div>
    );
  }

  return (
    <div className="chat-pane">
      <div className="chat-scroll" ref={scrollRef}>
        <div className="chat-stream">
          {stream.map((m, i) => {
            if (m.kind === "step") return <StepBadge key={i} label={m.label} done={m.done} />;
            if (m.kind === "assistant") return (
              <AssistantMessage key={i}>
                {m.body.map((line, k) => <ParagraphFromMarkdown key={k} text={line} />)}
              </AssistantMessage>
            );
            if (m.kind === "assistant-typing") return <TypingMessage key={i} label={m.label} />;
            if (m.kind === "user") return <UserMessage key={i} body={m.body} truncated={m.truncated} />;
            if (m.kind === "action-paste") return <ActionPaste key={i} title={m.title} placeholder={m.placeholder} onSubmit={onPasteSubmit} />;
            if (m.kind === "stats") return <StatsCard key={i} {...m} />;
            if (m.kind === "question") return <QuestionCard key={i} {...m} />;
            if (m.kind === "generating-done") return <GeneratingCard key={i} label={m.label} done />;
            return null;
          })}
        </div>
      </div>
      <Composer />
    </div>
  );
}

window.ChatView = ChatView;
window.Welcome = Welcome;
