// Preview pane — shows CV (Original / Tailored / Diff)
function PreviewPane({ phase, tab, setTab, resume }) {
  // phase: "empty" | "diagnostic" | "adapted"
  const showAdapted = phase === "adapted";

  if (phase === "empty") {
    return (
      <aside className="preview-pane">
        <div className="pv-top">
          <div className="pv-title-group">
            <IcoDoc size={14} style={{ color: "var(--muted)" }} />
            <div className="pv-title">CV — aperçu</div>
          </div>
        </div>
        <div className="pv-empty">
          <div className="ev-ico"><IcoDoc size={28} /></div>
          <div className="ev-title">L'aperçu apparaîtra ici</div>
          <div className="ev-sub">Collez une offre dans le chat ; je l'analyse, vous demande les infos manquantes, puis je génère le CV adapté à droite.</div>
        </div>
      </aside>
    );
  }

  return (
    <aside className="preview-pane">
      <div className="pv-top">
        <div className="pv-title-group">
          <IcoDoc size={14} style={{ color: "var(--muted)" }} />
          <div className="pv-title">{showAdapted ? "CV adapté" : "CV de base"}</div>
        </div>
        <div className="pv-tabs">
          <button className={tab === "original" ? "on" : ""} onClick={() => setTab("original")}>Original</button>
          <button className={tab === "adapted"  ? "on" : ""} onClick={() => setTab("adapted")} disabled={!showAdapted} style={{ opacity: showAdapted ? 1 : 0.4 }}>Adapté</button>
          <button className={tab === "diff"     ? "on" : ""} onClick={() => setTab("diff")} disabled={!showAdapted} style={{ opacity: showAdapted ? 1 : 0.4 }}>Diff</button>
        </div>
        <div className="pv-actions">
          <button className="sb-ico-btn" title="Télécharger"><IcoDownload size={14} /></button>
          <button className="sb-ico-btn" title="Ouvrir dans un onglet"><IcoExternal size={14} /></button>
        </div>
      </div>

      <div className="pv-body">
        <CVPaper resume={resume} mode={showAdapted ? tab : "original"} />
      </div>
    </aside>
  );
}

function CVPaper({ resume, mode }) {
  const showAdapted = mode === "adapted" || mode === "diff";
  const showDiff = mode === "diff";

  return (
    <div className="paper">
      <h1>{resume.name}</h1>
      <p className="ptitle">{resume.title}</p>
      <p className="pcontact">{resume.contact}</p>

      {resume.sections.map((s, i) => (
        <section key={i}>
          <h2>{s.title}</h2>
          {s.kind === "summary" && (
            <p style={{ margin: 0, fontSize: 13 }}>
              {showDiff ? (
                <>
                  <span style={{ display: "block", padding: "4px 8px", background: "var(--danger-soft)", borderLeft: "2px solid var(--danger)", borderRadius: 4, color: "var(--muted)", textDecoration: "line-through", marginBottom: 4 }}>{s.original}</span>
                  <span style={{ display: "block", padding: "4px 8px", background: "var(--accent-soft)", borderLeft: "2px solid var(--accent)", borderRadius: 4, color: "var(--ink)" }}>{s.adapted}</span>
                </>
              ) : (
                showAdapted ? s.adapted : s.original
              )}
            </p>
          )}
          {s.kind === "experience" && s.jobs.map((j, k) => (
            <div key={k} style={{ marginBottom: 14 }}>
              <h3>{j.role} · {j.company}</h3>
              <div className="period">{j.period}</div>
              <ul>
                {j.bullets.map((b, m) => {
                  if (!showAdapted && b.status === "added") return null;
                  const cls = showAdapted ? b.status : "";
                  if (showDiff && b.status === "rewritten") {
                    return (
                      <li key={m} className="" style={{ padding: 0 }}>
                        <div style={{ padding: "4px 8px", background: "var(--danger-soft)", borderLeft: "2px solid var(--danger)", borderRadius: 4, color: "var(--muted)", textDecoration: "line-through", margin: "2px 0" }}>{b.original}</div>
                        <div style={{ padding: "4px 8px", background: "var(--accent-soft)", borderLeft: "2px solid var(--accent)", borderRadius: 4, color: "var(--ink)", margin: "2px 0" }}>{b.text}</div>
                      </li>
                    );
                  }
                  return <li key={m} className={cls}>{showAdapted ? b.text : (b.original || b.text)}</li>;
                })}
              </ul>
            </div>
          ))}
          {s.kind === "skills" && (
            <p style={{ margin: 0, fontSize: 13 }}>
              {showDiff ? (
                <>
                  <span style={{ display: "block", padding: "4px 8px", background: "var(--danger-soft)", borderLeft: "2px solid var(--danger)", borderRadius: 4, color: "var(--muted)", textDecoration: "line-through", marginBottom: 4 }}>{s.original}</span>
                  <span style={{ display: "block", padding: "4px 8px", background: "var(--accent-soft)", borderLeft: "2px solid var(--accent)", borderRadius: 4, color: "var(--ink)" }}>{s.adapted}</span>
                </>
              ) : (
                showAdapted ? s.adapted : s.original
              )}
            </p>
          )}
        </section>
      ))}
    </div>
  );
}

window.PreviewPane = PreviewPane;
window.CVPaper = CVPaper;
