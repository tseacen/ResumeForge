// Setup phase — AI provider config + base CV import (2 steps)

function StepRail({ step }) {
  // step: 1 = ai, 2 = cv, 3 = ready
  const steps = [
    { num: 1, label: "Configurer l'IA" },
    { num: 2, label: "Ajouter le CV de base" },
    { num: 3, label: "Prêt à adapter" },
  ];
  return (
    <div className="step-rail">
      {steps.map((s, i) => (
        <React.Fragment key={s.num}>
          <div className={`step-pill ${step === s.num ? "active" : ""} ${step > s.num ? "done" : ""}`}>
            <span className="num">{step > s.num ? <IcoCheck2 size={11} sw={2.4} /> : s.num}</span>
            {s.label}
          </div>
          {i < steps.length - 1 && <div className="step-sep"></div>}
        </React.Fragment>
      ))}
    </div>
  );
}

function ProviderCard({ p, selected, status, onSelect, onTest }) {
  const isClaude = p.id === "claude";
  const handleKey = (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onSelect(p.id); }
  };
  return (
    <div
      className={`provider ${selected ? "selected" : ""}`}
      onClick={() => onSelect(p.id)}
      role="button"
      tabIndex={0}
      onKeyDown={handleKey}
    >
      <div className="provider-check"><IcoCheck2 size={13} sw={2.4} /></div>
      <div className="provider-head">
        <div className={`provider-logo ${isClaude ? "claude" : "codex"}`}>
          {isClaude ? <IcoAnthropic size={22} /> : <IcoOpenAI size={22} />}
        </div>
        <div>
          <div className="provider-name">{p.name}</div>
          <div className="provider-sub">{p.sub}</div>
        </div>
      </div>
      <p className="provider-desc">{p.desc}</p>
      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        <span className={`provider-status ${status}`}>
          <span className="dot"></span>
          {status === "idle" && "Non testé"}
          {status === "checking" && "Test en cours…"}
          {status === "available" && "Disponible · CLI détecté"}
          {status === "unavailable" && "CLI introuvable"}
        </span>
        <button
          className="btn sm"
          onClick={(e) => { e.stopPropagation(); onTest(p.id); }}
        >
          <IcoTestTube size={12} /> Tester
        </button>
      </div>
    </div>
  );
}

function SetupAI({ onContinue }) {
  const [selected, setSelected] = React.useState("claude");
  const [statuses, setStatuses] = React.useState({ claude: "available", codex: "idle" });

  const test = (id) => {
    setStatuses(s => ({ ...s, [id]: "checking" }));
    setTimeout(() => {
      setStatuses(s => ({ ...s, [id]: id === "claude" ? "available" : "unavailable" }));
    }, 1400);
  };

  const canContinue = statuses[selected] === "available";

  return (
    <div className="page-pad fade-in">
      <div className="setup-hero">
        <div className="setup-eyebrow">
          <span className="dot"></span>
          Bienvenue · première configuration
        </div>
        <h1 className="setup-h1">Choisissez votre <em>moteur</em> d'adaptation.</h1>
        <p className="setup-lede">
          ResumeForge s'appuie sur un assistant local — Claude Code ou Codex.
          Aucune donnée ne quitte votre machine au-delà des appels à votre IA configurée.
        </p>
      </div>

      <StepRail step={1} />

      <div className="provider-grid">
        {AI_PROVIDERS.map(p => (
          <ProviderCard
            key={p.id}
            p={p}
            selected={selected === p.id}
            status={statuses[p.id]}
            onSelect={setSelected}
            onTest={test}
          />
        ))}
      </div>

      <div style={{ marginTop: 22, padding: "14px 16px", background: "var(--bg-2)", border: "1px solid var(--line)", borderRadius: 10, display: "flex", gap: 12, alignItems: "flex-start" }}>
        <div style={{ width: 26, height: 26, borderRadius: 7, background: "var(--card)", border: "1px solid var(--line)", display: "grid", placeItems: "center", color: "var(--muted)", flex: "0 0 26px" }}>
          <IcoTerminal size={14} />
        </div>
        <div style={{ fontSize: 13, color: "var(--ink-3)", lineHeight: 1.55 }}>
          {statuses[selected] === "unavailable" ? (
            <>
              <strong style={{ color: "var(--ink)" }}>CLI non détecté.</strong>{" "}
              Installez-le via <code style={{ background: "var(--card)", padding: "1px 6px", borderRadius: 4, border: "1px solid var(--line)", fontSize: 12, fontFamily: "var(--font-mono)" }}>{AI_PROVIDERS.find(x => x.id === selected).install}</code>{" "}
              puis relancez le test.
            </>
          ) : (
            <>
              ResumeForge utilisera l'environnement <strong style={{ color: "var(--ink)" }}>{AI_PROVIDERS.find(x => x.id === selected).name}</strong>{" "}
              déjà installé. Vos clés d'API restent dans la config du CLI.
            </>
          )}
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 28, gap: 10 }}>
        <button className="btn">Configurer plus tard</button>
        <button className="btn primary lg" disabled={!canContinue} onClick={onContinue} style={{ opacity: canContinue ? 1 : 0.5 }}>
          Continuer <IcoArrowUp size={14} sw={2.2} style={{ transform: "rotate(90deg)" }} />
        </button>
      </div>
    </div>
  );
}

function SetupCV({ onContinue, onBack }) {
  const [tab, setTab] = React.useState("paste");
  const [pasteValue, setPasteValue] = React.useState(SAMPLE_RESUME_HTML);
  const [dragOver, setDragOver] = React.useState(false);
  const [fileName, setFileName] = React.useState(null);

  const hasContent = (tab === "paste" && pasteValue.trim().length > 100) || (tab === "file" && fileName);

  return (
    <div className="page-pad fade-in">
      <div className="setup-hero">
        <div className="setup-eyebrow">
          <span className="dot"></span>
          Étape 2 · CV de base
        </div>
        <h1 className="setup-h1">Importez votre <em>CV maître</em>.</h1>
        <p className="setup-lede">
          C'est la base que ResumeForge adaptera à chaque offre. Au format HTML —
          collez le code ou déposez le fichier. Vous pourrez le modifier à tout moment.
        </p>
      </div>

      <StepRail step={2} />

      <div className="cv-import">
        <div className="cv-import-tabs">
          <button className={`cv-tab ${tab === "paste" ? "on" : ""}`} onClick={() => setTab("paste")}>
            <IcoCommand size={13} /> Coller le HTML
          </button>
          <button className={`cv-tab ${tab === "file" ? "on" : ""}`} onClick={() => setTab("file")}>
            <IcoUpload size={13} /> Déposer un fichier
          </button>
        </div>

        <div className="cv-import-body">
          {tab === "paste" && (
            <textarea
              className="cv-import-paste"
              value={pasteValue}
              onChange={e => setPasteValue(e.target.value)}
              placeholder="<!DOCTYPE html>&#10;<html>&#10;  <body>&#10;    <h1>Votre nom</h1>&#10;    ..."
              spellCheck={false}
            />
          )}
          {tab === "file" && (
            <div
              className={`cv-import-drop ${dragOver ? "over" : ""}`}
              onDragOver={e => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={e => { e.preventDefault(); setDragOver(false); setFileName("cv-alex-morgan.html"); }}
            >
              <div className="di-icon"><IcoUpload size={22} /></div>
              <div className="di-title">{fileName ? fileName : "Déposez votre fichier .html"}</div>
              <div className="di-hint">
                {fileName
                  ? "Importé. Cliquez sur Continuer pour valider, ou redéposez pour remplacer."
                  : "Glissez-déposez votre CV au format HTML, ou cliquez pour choisir un fichier sur votre machine."}
              </div>
              {!fileName && <button className="btn sm" onClick={() => setFileName("cv-alex-morgan.html")}>Parcourir…</button>}
            </div>
          )}
        </div>

        <div className="cv-import-foot">
          <div className="filemeta">
            {hasContent ? (
              <>
                <span className="ok"><IcoCheck2 size={12} sw={2.4} /> Détecté</span>
                <span>·</span>
                <span className="mono">{tab === "paste" ? `${(pasteValue.length / 1024).toFixed(1)} ko` : "12.4 ko"}</span>
                <span>·</span>
                <span>3 expériences · 7 compétences</span>
              </>
            ) : (
              <>En attente d'un CV…</>
            )}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn sm" disabled={!hasContent}><IcoEye size={12} /> Aperçu</button>
          </div>
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 28, gap: 10 }}>
        <button className="btn" onClick={onBack}>Retour</button>
        <button className="btn primary lg" disabled={!hasContent} onClick={onContinue} style={{ opacity: hasContent ? 1 : 0.5 }}>
          Enregistrer & commencer <IcoArrowUp size={14} sw={2.2} style={{ transform: "rotate(90deg)" }} />
        </button>
      </div>
    </div>
  );
}

window.SetupAI = SetupAI;
window.SetupCV = SetupCV;
window.StepRail = StepRail;
