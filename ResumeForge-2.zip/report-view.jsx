// Report tab — strengths/weaknesses cards + blockers/risks banners
function ItemRow({ tone, icon, title, text }) {
  return (
    <div className={`item-row ${tone}`}>
      <div className="iico">{icon}</div>
      <div className="it-body">
        <div className="it-title">{title}</div>
        <div className="it-text">{text}</div>
      </div>
    </div>
  );
}

function ExpRow({ num, title, tag, tone, body, fix }) {
  const [open, setOpen] = React.useState(false);
  return (
    <div className={`exp-row ${open ? "open" : ""}`}>
      <div className="exp-head" onClick={() => setOpen((v) => !v)}>
        <div className="exp-num mono">{num}</div>
        <div className="exp-title">{title}</div>
        <span className={`exp-tag ${tone}`}>{tag}</span>
        <span className="exp-chev"><IconChevron size={14} /></span>
      </div>
      <div className="exp-body">
        <div>{body}</div>
        <div className="fix-card">
          <div className="fix-label">Suggested fix</div>
          <div>{fix}</div>
        </div>
      </div>
    </div>
  );
}

function ReportView({ analysis }) {
  const { strengths, weaknesses, blockers, risks } = analysis;

  return (
    <div className="tab-fade">
      <div className="page-title-row">
        <div>
          <h1 className="h1">Fit report</h1>
          <div className="lede">The headline of how this resume reads against the job — strengths to lean into, weaknesses to address, and what's actually blocking submission.</div>
        </div>
      </div>

      <ScoreDashboard analysis={analysis} />

      <div className="two-col" style={{ marginBottom: 20 }}>
        <div className="card pad">
          <div className="col-head">
            <div className="col-title">
              <span className="col-icon green"><IconCheck size={14} sw={2.2} /></span>
              Strengths
            </div>
            <span className="col-count">{strengths.length}</span>
          </div>
          {strengths.map((s, i) => (
            <ItemRow key={i} tone="green"
              icon={<IconCheck size={12} sw={2.4} />}
              title={s.title} text={s.text} />
          ))}
        </div>

        <div className="card pad">
          <div className="col-head">
            <div className="col-title">
              <span className="col-icon amber"><IconAlert size={14} sw={2.2} /></span>
              Weaknesses
            </div>
            <span className="col-count">{weaknesses.length}</span>
          </div>
          {weaknesses.map((w, i) => (
            <ItemRow key={i} tone="amber"
              icon={<IconAlert size={12} sw={2.2} />}
              title={w.title} text={w.text} />
          ))}
        </div>
      </div>

      <div style={{ marginBottom: 20 }}>
        <div className="banner red">
          <div className="bn-icon"><IconCircleX size={18} sw={2} /></div>
          <div>
            <div className="bn-title">Blockers</div>
            <div className="bn-sub">Will likely kill the application if not addressed before submission.</div>
          </div>
          <span className="bn-count">{blockers.length}</span>
        </div>
        {blockers.map((b, i) => (
          <ExpRow key={i} num={b.num} title={b.title} tag={b.tag} tone={b.tone} body={b.body} fix={b.fix} />
        ))}
      </div>

      <div>
        <div className="banner orange">
          <div className="bn-icon"><IconAlert size={18} sw={2} /></div>
          <div>
            <div className="bn-title">Interview risks</div>
            <div className="bn-sub">Likely-to-come-up topics where this resume needs a rehearsed answer.</div>
          </div>
          <span className="bn-count">{risks.length}</span>
        </div>
        {risks.map((r, i) => (
          <ExpRow key={i} num={r.num} title={r.title} tag={r.tag} tone={r.tone} body={r.body} fix={r.fix} />
        ))}
      </div>
    </div>
  );
}

window.ReportView = ReportView;
