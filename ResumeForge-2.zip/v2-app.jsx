// Main app shell — drives the phase state machine

const PHASES = {
  SETUP_AI: "setup-ai",
  SETUP_CV: "setup-cv",
  EMPTY:    "ready-empty",
  DIAGNOSTIC: "chat-diagnostic",
  ADAPTED:  "chat-adapted",
};

function TopBar({ phase, chatTitle, onReset }) {
  const isSetup = phase === PHASES.SETUP_AI || phase === PHASES.SETUP_CV;
  return (
    <div className="topbar">
      <div className="tb-left">
        {isSetup ? (
          <div className="tb-title">Configuration <em>initiale</em></div>
        ) : phase === PHASES.EMPTY ? (
          <div className="tb-title">Nouvelle <em>adaptation</em></div>
        ) : (
          <>
            <div className="tb-title">{chatTitle}</div>
            <span className="tb-sub mono">v3 · brouillon</span>
          </>
        )}
      </div>
      <div className="tb-actions">
        {!isSetup && phase !== PHASES.EMPTY && (
          <>
            <button className="btn ghost sm"><IcoHistory size={13} /> Historique</button>
            <button className="btn sm"><IcoDownload size={13} /> Exporter</button>
          </>
        )}
        {!isSetup && (
          <button className="btn sm" onClick={onReset}><IcoRefresh size={13} /> Réinitialiser</button>
        )}
      </div>
    </div>
  );
}

function App() {
  // Tweaks for jumping between phases / tweaking visuals
  const [t, setTweak] = useTweaks(
    /*EDITMODE-BEGIN*/{
      "phase": "ready-empty",
      "accent": "#C96442",
      "sidebar": true
    }/*EDITMODE-END*/
  );

  // Active phase derived from tweaks
  const phase = t.phase;

  // Preview tab state (original / adapted / diff)
  const [pvTab, setPvTab] = React.useState("adapted");
  React.useEffect(() => {
    if (phase === PHASES.ADAPTED) setPvTab("adapted");
    else setPvTab("original");
  }, [phase]);

  // Apply accent live
  React.useEffect(() => {
    document.documentElement.style.setProperty("--accent", t.accent);
    // Derive a hover by darkening — naive but fine for prototype
    document.documentElement.style.setProperty("--accent-hover", shade(t.accent, -10));
  }, [t.accent]);

  const onNewChat = () => setTweak("phase", PHASES.EMPTY);
  const onPasteSubmit = () => setTweak("phase", PHASES.DIAGNOSTIC);
  const onReset = () => setTweak("phase", PHASES.EMPTY);

  // What does the preview pane show?
  const previewPhase =
    phase === PHASES.SETUP_AI || phase === PHASES.SETUP_CV || phase === PHASES.EMPTY ? "empty"
    : phase === PHASES.DIAGNOSTIC ? "diagnostic"
    : "adapted";

  const isSetup = phase === PHASES.SETUP_AI || phase === PHASES.SETUP_CV;
  const isChat = phase === PHASES.EMPTY || phase === PHASES.DIAGNOSTIC || phase === PHASES.ADAPTED;

  return (
    <div className="app">
      {t.sidebar && (
        <Sidebar
          activeChat={phase === PHASES.ADAPTED || phase === PHASES.DIAGNOSTIC ? "c1" : null}
          onNewChat={onNewChat}
        />
      )}
      <div className="main" style={{ gridColumn: t.sidebar ? "auto" : "1 / -1" }}>
        <TopBar
          phase={phase}
          chatTitle="Staff Product Engineer — Lumen"
          onReset={onReset}
        />

        {isSetup ? (
          <div className="page">
            {phase === PHASES.SETUP_AI && <SetupAI onContinue={() => setTweak("phase", PHASES.SETUP_CV)} />}
            {phase === PHASES.SETUP_CV && <SetupCV
              onContinue={() => setTweak("phase", PHASES.EMPTY)}
              onBack={() => setTweak("phase", PHASES.SETUP_AI)}
            />}
          </div>
        ) : (
          <div className="page page-wide">
            <div className="chat-shell" style={{ gridTemplateColumns: phase === PHASES.EMPTY ? "1fr" : undefined }}>
              <ChatView phase={
                phase === PHASES.EMPTY ? "empty" :
                phase === PHASES.DIAGNOSTIC ? "diagnostic" :
                "adapted"
              } onPasteSubmit={onPasteSubmit} />
              {phase !== PHASES.EMPTY && (
                <PreviewPane
                  phase={previewPhase}
                  tab={pvTab}
                  setTab={setPvTab}
                  resume={V2_RESUME}
                />
              )}
            </div>
          </div>
        )}
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Démo">
          <TweakSelect
            label="Phase"
            value={t.phase}
            onChange={(v) => setTweak("phase", v)}
            options={[
              { value: PHASES.SETUP_AI, label: "1. Setup — Configurer l'IA" },
              { value: PHASES.SETUP_CV, label: "2. Setup — Importer le CV" },
              { value: PHASES.EMPTY, label: "3. Chat vide (welcome)" },
              { value: PHASES.DIAGNOSTIC, label: "4. Chat — diagnostic + questions" },
              { value: PHASES.ADAPTED, label: "5. Chat — CV adapté généré" },
            ]}
          />
          <TweakToggle
            label="Afficher le sidebar"
            value={t.sidebar}
            onChange={(v) => setTweak("sidebar", v)}
          />
        </TweakSection>
        <TweakSection title="Apparence">
          <TweakColor
            label="Couleur d'accent"
            value={t.accent}
            options={["#C96442", "#1F8A5B", "#3B6CB5", "#8B5A8B", "#1F1E1B"]}
            onChange={(v) => setTweak("accent", v)}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

// Helper: shade hex by percentage
function shade(hex, pct) {
  const num = parseInt(hex.replace("#", ""), 16);
  const r = Math.max(0, Math.min(255, ((num >> 16) & 0xff) + Math.round((pct / 100) * 255)));
  const g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + Math.round((pct / 100) * 255)));
  const b = Math.max(0, Math.min(255, (num & 0xff) + Math.round((pct / 100) * 255)));
  return "#" + ((r << 16) | (g << 8) | b).toString(16).padStart(6, "0");
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
