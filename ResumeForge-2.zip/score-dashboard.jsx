// Score dashboard — circular SVG gauge + horizontal sub-score bars
function colorFor(v) {
  if (v >= 80) return "green";
  if (v >= 60) return "amber";
  return "red";
}

function strokeFor(v) {
  if (v >= 80) return "#10B981";
  if (v >= 60) return "#F59E0B";
  return "#EF4444";
}

function SubIcon({ id }) {
  const size = 13;
  if (id === "target")    return <IconTarget size={size} />;
  if (id === "briefcase") return <IconBriefcase size={size} />;
  if (id === "tag")       return <IconTag size={size} />;
  if (id === "layers")    return <IconLayers size={size} />;
  if (id === "chart")     return <IconChart size={size} />;
  return <IconCircleDot size={size} />;
}

function ScoreGauge({ value }) {
  const R = 84;
  const C = 2 * Math.PI * R;
  const [progress, setProgress] = React.useState(0);

  React.useEffect(() => {
    const t = requestAnimationFrame(() => setProgress(value));
    return () => cancelAnimationFrame(t);
  }, [value]);

  const offset = C - (progress / 100) * C;

  return (
    <div className="gauge-wrap">
      <div className="gauge-center" style={{ pointerEvents: "none" }}>
        <div className="gauge-num">{value}</div>
        <div className="gauge-of">out of 100</div>
      </div>
      <svg width="200" height="200" viewBox="0 0 200 200">
        <circle
          cx="100" cy="100" r={R}
          fill="none" stroke="#F4F4F6" strokeWidth="14"
        />
        <circle
          cx="100" cy="100" r={R}
          fill="none"
          stroke={strokeFor(value)}
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1100ms cubic-bezier(0.22,1,0.36,1)" }}
        />
      </svg>
    </div>
  );
}

function ScoreDashboard({ analysis }) {
  const { global_score, risk_level, sub_scores } = analysis;
  const [showBars, setShowBars] = React.useState(false);

  React.useEffect(() => {
    const t = setTimeout(() => setShowBars(true), 150);
    return () => clearTimeout(t);
  }, []);

  const riskTone =
    risk_level === "low" ? "green" :
    risk_level === "moderate" ? "amber" : "red";

  const riskLabel = ({
    low: "Low risk · ready to send",
    moderate: "Moderate risk · address before submission",
    high: "High risk · do not submit yet",
  })[risk_level] || risk_level;

  return (
    <div className="dash-grid" style={{ marginBottom: 16 }}>
      <div className="card gauge-card">
        <div className="gauge-label">Global fit score</div>
        <ScoreGauge value={global_score} />
        <div className={`risk-pill ${riskTone}`}>
          <span className="rkdot"></span>
          {riskLabel}
        </div>
      </div>

      <div className="card subs-card">
        <div className="subs-head">
          <div>
            <div className="card-eyebrow">Sub-scores</div>
            <div className="card-title">Breakdown across five dimensions</div>
          </div>
          <button className="pill-btn ghost" style={{ height: 28 }}>
            <IconRefresh size={12} /> Recompute
          </button>
        </div>

        {sub_scores.map((s, i) => (
          <div className="sub-row" key={s.id}>
            <div className="sub-label">
              <span className="lico"><SubIcon id={s.icon} /></span>
              {s.label}
            </div>
            <div className="sub-bar">
              <div
                className={`fill ${colorFor(s.value)}`}
                style={{
                  width: showBars ? `${s.value}%` : "0%",
                  transitionDelay: `${i * 130}ms`,
                }}
              />
            </div>
            <div className="sub-num">{s.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

window.ScoreDashboard = ScoreDashboard;
window.colorFor = colorFor;
