// Missing keywords — masonry chip grid styled by importance
function KeywordsView({ analysis }) {
  const kws = analysis.missing_keywords;
  const counts = kws.reduce((acc, k) => { acc[k.importance] = (acc[k.importance] || 0) + 1; return acc; }, {});
  const [filter, setFilter] = React.useState("all");
  const visible = filter === "all" ? kws : kws.filter((k) => k.importance === filter);

  const iconFor = (imp) => {
    if (imp === "required") return <IconCircleX size={11} sw={2.2} />;
    if (imp === "preferred") return <IconAlert size={11} sw={2.2} />;
    return <IconCircleDot size={10} sw={2} />;
  };

  return (
    <div className="tab-fade">
      <div className="page-title-row">
        <div>
          <h1 className="h1">Missing keywords</h1>
          <div className="lede">Terms the job description repeats that don't appear on the resume — triaged by how badly they need to be addressed.</div>
        </div>
      </div>

      <div className="kw-summary">
        <div className="summary-dot red">
          <span className="sd-dot"></span>
          <span className="sd-num">{counts.required || 0}</span> required
        </div>
        <div className="sep"></div>
        <div className="summary-dot amber">
          <span className="sd-dot"></span>
          <span className="sd-num">{counts.preferred || 0}</span> preferred
        </div>
        <div className="sep"></div>
        <div className="summary-dot" style={{ color: "var(--muted)" }}>
          <span className="sd-dot" style={{ background: "var(--muted-2)" }}></span>
          <span className="sd-num">{counts.bonus || 0}</span> bonus
        </div>

        <div className="kw-filter">
          {["all", "required", "preferred", "bonus"].map((k) => (
            <button key={k} className={filter === k ? "on" : ""} onClick={() => setFilter(k)}>
              {k === "all" ? "All" : k.charAt(0).toUpperCase() + k.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="kw-grid">
        {visible.map((k, i) => (
          <div key={i} className={`kw-chip ${k.importance}`}>
            <span className="kico">{iconFor(k.importance)}</span>
            <span>{k.term}</span>
            <span className="kcat">{k.category}</span>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 24 }} className="card pad">
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 8,
            background: "var(--indigo-soft)", color: "var(--indigo)",
            display: "grid", placeItems: "center",
          }}>
            <IconWand size={18} sw={1.8} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 16, fontWeight: 600, color: "var(--ink)", letterSpacing: "-0.01em" }}>Want a draft that addresses the required keywords?</div>
            <div style={{ fontSize: 13.5, color: "var(--muted)", marginTop: 4 }}>
              We'll only weave in terms the audit shows are substantiated by your existing experience — never fabricated.
            </div>
          </div>
          <button className="pill-btn primary">
            <IconBolt size={13} sw={2} /> Draft revisions
          </button>
        </div>
      </div>
    </div>
  );
}

window.KeywordsView = KeywordsView;
