// Audit panel — timeline-style list of audit items
function AuditView({ analysis }) {
  const items = analysis.audit;
  const counts = items.reduce((acc, it) => {
    acc[it.classification] = (acc[it.classification] || 0) + 1;
    return acc;
  }, {});

  const classLabel = {
    proven: "Proven",
    rewritten: "Rewritten",
    needs_validation: "Needs validation",
    blocked: "Blocked",
  };
  const classTone = {
    proven: "green",
    rewritten: "blue",
    needs_validation: "amber",
    blocked: "red",
  };
  const riskTone = {
    none: "muted", low: "muted", moderate: "amber", high: "red",
  };

  const [filter, setFilter] = React.useState("all");
  const visible = filter === "all" ? items : items.filter((i) => i.classification === filter);

  return (
    <div className="tab-fade">
      <div className="page-title-row">
        <div>
          <h1 className="h1">Audit trail</h1>
          <div className="lede">Every change the agent made, every line it kept, and every claim it could not verify. No silent rewrites.</div>
        </div>
      </div>

      <div className="audit-summary">
        <div className="summary-dot green">
          <span className="sd-dot"></span>
          <span className="sd-num">{counts.proven || 0}</span> proven
        </div>
        <div className="sep"></div>
        <div className="summary-dot blue">
          <span className="sd-dot"></span>
          <span className="sd-num">{counts.rewritten || 0}</span> rewritten
        </div>
        <div className="sep"></div>
        <div className="summary-dot amber">
          <span className="sd-dot"></span>
          <span className="sd-num">{counts.needs_validation || 0}</span> needs validation
        </div>
        <div className="sep"></div>
        <div className="summary-dot red">
          <span className="sd-dot"></span>
          <span className="sd-num">{counts.blocked || 0}</span> blocked
        </div>

        <div className="kw-filter">
          {["all", "proven", "rewritten", "needs_validation", "blocked"].map((k) => (
            <button key={k} className={filter === k ? "on" : ""} onClick={() => setFilter(k)}>
              {k === "all" ? "All" : classLabel[k]}
            </button>
          ))}
        </div>
      </div>

      {visible.map((item, i) => (
        <div key={i} className={`audit-row ${item.classification}`}>
          <div className="audit-bar"></div>
          <div className="audit-body">
            <div className="audit-top">
              <span className="chip">{item.section}</span>
              <span className={`chip ${classTone[item.classification]}`}>
                <span className="cdot"></span>
                {classLabel[item.classification]}
              </span>
              <span className={`chip ${riskTone[item.risk]}`}>risk · {item.risk}</span>
            </div>
            <div className="audit-reason">{item.reason}</div>
          </div>
        </div>
      ))}

      {visible.length === 0 && (
        <div className="card pad" style={{ textAlign: "center", color: "var(--muted)" }}>
          Nothing matches that filter.
        </div>
      )}
    </div>
  );
}

window.AuditView = AuditView;
