// Analyze view — two side-by-side drop zones + Analyze CTA
function DropZone({ label, icon, value, onChange, placeholder, hint }) {
  const [dragOver, setDragOver] = React.useState(false);
  const inputRef = React.useRef(null);
  const filled = value && value.length > 0;

  const handleFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => onChange(String(e.target.result || ""));
    reader.readAsText(file);
  };

  const onDrop = (e) => {
    e.preventDefault(); setDragOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) handleFile(f);
  };

  return (
    <div
      className={`drop ${filled ? "filled" : ""} ${dragOver ? "dragover" : ""}`}
      onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={onDrop}
    >
      <div className="drop-head">
        <div className="label">
          <span className="ico">{icon}</span>
          {label}
        </div>
        {filled && (
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <span className="check-badge">
              <span className="dot"></span>
              <IconCheck size={11} sw={2.4} />
              loaded
            </span>
            <button
              onClick={() => onChange("")}
              style={{
                background: "transparent", border: 0, cursor: "pointer",
                color: "var(--muted)", padding: 2, display: "grid", placeItems: "center"
              }}
              title="Clear"
            >
              <IconClose size={14} />
            </button>
          </div>
        )}
      </div>

      {!filled ? (
        <div className="drop-empty" onClick={() => inputRef.current?.click()}>
          <div className="dico"><IconUpload size={20} /></div>
          <div className="dtitle">{placeholder}</div>
          <div className="dhint">{hint}</div>
          <button type="button" className="dchoose" onClick={(e) => { e.stopPropagation(); inputRef.current?.click(); }}>
            Browse files
          </button>
        </div>
      ) : (
        <div className="drop-filled-body">
          <div className="drop-meta">
            <span className="mono">{value.length.toLocaleString()} chars</span>
            <span style={{ color: "var(--line-2)" }}>·</span>
            <span>{(value.split("\n").length).toLocaleString()} lines</span>
          </div>
          <div className="drop-preview">{value.slice(0, 1400)}{value.length > 1400 ? "\n…" : ""}</div>
          <div className="drop-actions">
            <button className="pill-btn" onClick={() => inputRef.current?.click()}>
              <IconUpload size={13} /> Replace
            </button>
            <button className="pill-btn ghost" onClick={() => navigator.clipboard?.writeText(value)}>
              <IconCopy size={13} /> Copy
            </button>
          </div>
        </div>
      )}

      <input
        ref={inputRef}
        type="file"
        accept=".html,.htm,.txt,.md,.json"
        style={{ display: "none" }}
        onChange={(e) => handleFile(e.target.files?.[0])}
      />
    </div>
  );
}

function AnalyzeView({ resumeHtml, setResumeHtml, jobText, setJobText, onAnalyze, loading, analyzed }) {
  const canAnalyze = resumeHtml.trim().length > 0 && jobText.trim().length > 0 && !loading;

  return (
    <div className="tab-fade">
      <div className="page-title-row">
        <div>
          <h1 className="h1">Tailor a new application</h1>
          <div className="lede">Drop your resume and the job description. We'll score the fit, surface blockers, and rewrite weak lines without inventing facts.</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="pill-btn" onClick={() => { setResumeHtml(SAMPLE_RESUME_HTML); setJobText(SAMPLE_JOB); }}>
            <IconSparkle size={13} /> Load sample
          </button>
          <button className="pill-btn ghost" onClick={() => { setResumeHtml(""); setJobText(""); }}>
            <IconClose size={13} /> Clear
          </button>
        </div>
      </div>

      <div className="input-grid">
        <DropZone
          label="Resume (HTML)"
          icon={<IconDoc size={14} />}
          value={resumeHtml}
          onChange={setResumeHtml}
          placeholder="Drop your resume HTML or click to browse"
          hint=".html exported from Docs, Notion, or any builder"
        />
        <DropZone
          label="Job description"
          icon={<IconBriefcase size={14} />}
          value={jobText}
          onChange={setJobText}
          placeholder="Drop the JD as text or click to browse"
          hint="Plain text, Markdown, or scraped HTML — all welcome"
        />
      </div>

      <button
        className={`analyze ${loading ? "loading" : ""}`}
        disabled={!canAnalyze}
        onClick={onAnalyze}
      >
        {loading ? (
          <>
            <span className="spinner"></span>
            <span>Analyzing fit · scoring · drafting rewrites…</span>
          </>
        ) : (
          <>
            <IconBolt size={16} sw={2} />
            <span>{analyzed ? "Re-run analysis" : "Analyze fit"}</span>
            <IconArrow size={15} />
          </>
        )}
      </button>

      <div style={{ marginTop: 14, display: "flex", alignItems: "center", justifyContent: "center", gap: 14, color: "var(--muted)", fontSize: 12 }}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
          <IconShield size={12} /> Runs locally — nothing leaves your machine
        </span>
        <span style={{ color: "var(--line-2)" }}>·</span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
          <IconHourglass size={12} /> Typical run: 20–35s
        </span>
      </div>
    </div>
  );
}

window.AnalyzeView = AnalyzeView;
